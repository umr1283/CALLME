labels.parGADA<-function(object,...)
  {
    attr(object,"labels.samples")
  }

labels.summaryParGADA<-function(object,...)
  {
    attr(object,"labels.samples")
  }
