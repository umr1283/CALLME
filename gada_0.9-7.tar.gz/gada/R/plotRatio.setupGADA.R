`plotRatio.setupGADA` <-
function(x, chr, chromStart, chromEnd, B.allele.freq=FALSE, ...)
{
 plotlogRatio(x, chr, chromStart, chromEnd, B.allele.freq, ...)
}

