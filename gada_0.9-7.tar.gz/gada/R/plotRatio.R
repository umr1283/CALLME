`plotRatio` <-
function(x,...)
 UseMethod("plotRatio")

